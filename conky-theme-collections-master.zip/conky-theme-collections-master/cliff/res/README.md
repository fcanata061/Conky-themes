Icons are extracted from Min Icons Pack
